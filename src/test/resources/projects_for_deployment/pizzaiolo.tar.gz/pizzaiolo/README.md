# Cas d'usage
WebApp pour les tests de montée en charge entre les containers Tomcat et Mysql
La base de données ne contient actuellement qu'une table et à chaque affiche on tape sur la base de données.
Ceci est volontaire pour faire des accès BDD.

# Configuration
Il existe deux façons de configurer les variables d'environnement

1.   Ajouter dans **servlet-context.xml** l'instruction **<context:property-placeholder/>** et utiliser la syntaxe **${MAVARIABLE}**
2.   Utiliser la syntaxe **#{systemProperties.MAVARIABLE}** par défaut de spring pour la prise en compte des variables d'env

Par défaut le choix 1 s'applique par simplicité.

# Initialisation de la base de données
1. Vous devez *a minima* créer la base de données.
2. Vous devez décommenter l'instruction **jdbc:initialize-database** dans **servlet-context.xml** pour créer les tables et les jeux de données.
3. Générer le war avec **mvn clean package**
4. Déployer le war. Les tables sont créées
5. Vous devez **commenter** l'instruction **jdbc:initialize-database** dans *servlet-context.xml* pour ne plus avoir à créer le jeu de données.
6. Les futurs WAR utiliseront la base de données existante.

Il est toujours possible de jouer manuellement le script database.sql fourni pour éviter ceci.
Pour ceci je vous conseille de vous connecter en ssh sur le container tomcat puis d'installer un client mysql via **sudo apt-get install mysql-client**
Vous pourrez alors vous connecter via mysql pour jouer le script en copier/collant le sql dans le terminal.



