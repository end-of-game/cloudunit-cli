CREATE TABLE pizza (
  id serial PRIMARY KEY,
  name VARCHAR(45) ,
  price integer);

INSERT INTO pizza (id, name, price) VALUES ('1', 'Reine', '7');
INSERT INTO pizza (id, name, price) VALUES ('2', 'Royale', '6');
INSERT INTO pizza (id, name, price) VALUES ('3', 'Pepperoni', '6');
