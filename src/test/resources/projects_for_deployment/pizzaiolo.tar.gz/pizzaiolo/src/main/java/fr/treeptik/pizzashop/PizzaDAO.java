package fr.treeptik.pizzashop;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@SuppressWarnings({"unchecked", "rawtypes"})
public class PizzaDAO {
	
	@Autowired private SessionFactory sessionFactory;
	
	@Transactional
	public List<Pizza> findAll() {
		Session session = sessionFactory.getCurrentSession();
		List pizzas = session.createQuery("from Pizza").list();
		return pizzas;
	}



}
